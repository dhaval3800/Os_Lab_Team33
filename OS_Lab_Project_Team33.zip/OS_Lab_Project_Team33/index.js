var scene = document.getElementById("scene");
var parallaxInstance = new Parallax(scene);
